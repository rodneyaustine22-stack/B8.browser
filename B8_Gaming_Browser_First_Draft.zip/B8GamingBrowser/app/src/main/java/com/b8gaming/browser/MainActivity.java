package com.b8gaming.browser;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.view.View;
import android.view.WindowManager;
import android.view.KeyEvent;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.text.InputType;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    private EditText addressBar;
    private LinearLayout toolbar;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ProgressBar progressBar;
    private static final String HOME_URL = "https://v2.fiveplay.lol/";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().setStatusBarColor(Color.rgb(8, 12, 10));
        getWindow().setNavigationBarColor(Color.rgb(8, 12, 10));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,12,10));
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new FrameLayout.LayoutParams(-1,-1));
        toolbar = new LinearLayout(this); toolbar.setOrientation(LinearLayout.HORIZONTAL); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8),dp(5),dp(8),dp(5)); toolbar.setBackgroundColor(Color.rgb(13,22,17));
        page.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView logo = new TextView(this); logo.setText("B8"); logo.setTextColor(Color.rgb(93,255,142)); logo.setTextSize(20); logo.setGravity(Gravity.CENTER); logo.setTypeface(null,1);
        toolbar.addView(logo,new LinearLayout.LayoutParams(dp(40),-1));
        addressBar = new EditText(this); addressBar.setSingleLine(true); addressBar.setText(HOME_URL); addressBar.setTextColor(Color.WHITE); addressBar.setHintTextColor(Color.LTGRAY); addressBar.setHint("Search or enter website"); addressBar.setTextSize(14); addressBar.setPadding(dp(10),0,dp(10),0); addressBar.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI); addressBar.setImeOptions(EditorInfo.IME_ACTION_GO); addressBar.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(70,130,88)));
        toolbar.addView(addressBar,new LinearLayout.LayoutParams(0,dp(40),1f));
        Button go=makeButton("GO"); toolbar.addView(go,new LinearLayout.LayoutParams(dp(52),dp(40))); go.setOnClickListener(v->loadAddress());
        Button home=makeButton("HOME"); toolbar.addView(home,new LinearLayout.LayoutParams(dp(56),dp(40))); home.setOnClickListener(v->webView.loadUrl(HOME_URL));
        Button full=makeButton("FULL"); toolbar.addView(full,new LinearLayout.LayoutParams(dp(54),dp(40))); full.setOnClickListener(v->enterImmersiveMode());
        addressBar.setOnEditorActionListener((v,actionId,event)->{ if(actionId==EditorInfo.IME_ACTION_GO || (event!=null && event.getKeyCode()==KeyEvent.KEYCODE_ENTER)){loadAddress();return true;} return false;});
        progressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progressBar.setMax(100); progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(93,255,142))); page.addView(progressBar,new LinearLayout.LayoutParams(-1,dp(3)));
        webView=new WebView(this); webView.setBackgroundColor(Color.BLACK); webView.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setJavaScriptCanOpenWindowsAutomatically(true); s.setSupportMultipleWindows(true); s.setLoadsImagesAutomatically(true); s.setMediaPlaybackRequiresUserGesture(false); s.setSupportZoom(true); s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false); s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true); s.setCacheMode(WebSettings.LOAD_DEFAULT); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView view,String url,Bitmap favicon){addressBar.setText(url);progressBar.setVisibility(View.VISIBLE);}
            @Override public void onPageFinished(WebView view,String url){addressBar.setText(url);progressBar.setVisibility(View.GONE);}
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){String scheme=request.getUrl().getScheme(); return !("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme));}
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onProgressChanged(WebView view,int p){progressBar.setProgress(p);if(p>=100)progressBar.setVisibility(View.GONE);}
            @Override public void onShowCustomView(View view,CustomViewCallback callback){if(customView!=null){callback.onCustomViewHidden();return;}customView=view;customViewCallback=callback;root.addView(customView,new FrameLayout.LayoutParams(-1,-1));toolbar.setVisibility(View.GONE);progressBar.setVisibility(View.GONE);enterImmersiveMode();}
            @Override public void onHideCustomView(){if(customView==null)return;root.removeView(customView);customView=null;if(customViewCallback!=null)customViewCallback.onCustomViewHidden();customViewCallback=null;toolbar.setVisibility(View.VISIBLE);showSystemBars();}
        });
        page.addView(webView,new LinearLayout.LayoutParams(-1,0,1f)); setContentView(root); webView.loadUrl(HOME_URL);
    }
    private Button makeButton(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.rgb(93,255,142));b.setTextSize(11);b.setAllCaps(false);b.setPadding(0,0,0,0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(24,43,30)));return b;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private void loadAddress(){String t=addressBar.getText().toString().trim();if(t.isEmpty())return;String u;if(t.matches("(?i)^https?://.*"))u=t;else if(t.contains(".")&&!t.contains(" "))u="https://"+t;else u="https://www.google.com/search?q="+Uri.encode(t);((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(addressBar.getWindowToken(),0);webView.loadUrl(u);}
    private void enterImmersiveMode(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
    private void showSystemBars(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
    @Override public void onBackPressed(){if(customView!=null){webView.evaluateJavascript("(function(){document.exitFullscreen&&document.exitFullscreen();})()",null);return;}if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.stopLoading();webView.setWebChromeClient(null);webView.setWebViewClient(null);webView.destroy();webView=null;}super.onDestroy();}
}
